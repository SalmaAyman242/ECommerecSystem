package javaapplication11;
import java.util.Scanner;
public class Cart extends Product{ //عملت انهريت عشان استخدم ميثودز برودكت هنا
   Scanner in=new Scanner(System.in);
   protected int customerid;
   protected int nProduct;
   protected Product[]Products;
  // private int counter=0;
   
  
   public Cart(){
       
   }
   
    public Cart(int customerid, int nProduct, Product[]Products) {
        this.customerid = customerid;
        this.nProduct = nProduct;
        this.Products = new Product[this.nProduct];
    }

    public void setCustomerid(int customerid) {
       if(customerid>0) {this.customerid = customerid;}
       else{this.customerid =Math.abs(customerid);}
    }
   
    public int getCustomerid() {
        return customerid;
    }
    
    public void setnProduct(int nProduct) {
      if(nProduct>0)  {this.nProduct = nProduct;}
      else{this.nProduct =Math.abs(nProduct);}
      Products=new Product[nProduct];
    }

    public int getnProduct() {
        return nProduct;
    }
    
    public void setProducts(Product[]Products) {
      this.Products = new Product[this.nProduct];
    }

    public Product[] getProducts() {
         return Products;
    }
    
    
    public void addProduct(Product product) {
       for (int i = 0; i < Products.length; i++) {
            if (Products[i] == null) {
                Products[i] = product;
                return; //بتطلع برا الفانكشن و تعيد من الاول بعد ما حطت الاوبجت في الارراي
            }
        }
       System.out.println("the cart is fall canot add  more product");
       
    }
    
    
    public void removeProduct(int z) {
      if(z>=0&& z<nProduct){
          Products[z]=null;
       }
      else{
          System.out.println("Invaild Index,cannot Remove Product ");
      }
        
    }
    
    public double calculatePrice() {
        double totalPrice = 0.0;
        for (Product product : Products) {
            if (product != null) {
                totalPrice += product.getPrice();  
            }
        }
        return totalPrice;
    }
    
   public void placeorder(int n){
   switch(n){
       case 1:
           System.out.println("the order has been placed successfuly");
         break;
       case 2:
           for(int k=0;k<Products.length;k++){
              Products[k]=null;
           }
            break; 
           
   
   }
          
   
   }
    
    

}
  

    
   
   

    
   

