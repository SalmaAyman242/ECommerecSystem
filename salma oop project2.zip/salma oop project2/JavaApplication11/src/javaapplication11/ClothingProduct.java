
package javaapplication11;
public class ClothingProduct extends Product {
    private String size;
    private String frabic;
    
    public ClothingProduct(){
    
    }

    public ClothingProduct( String name,int productid,float price,String size, String frabic) {
        super(productid, name, price);
        this.size = size;
        this.frabic = frabic;
    }
    
     public void setSize(String size) {
        this.size = size;
    }

    public String getSize() {
        return size;
    }
    
    public void setFrabic(String frabic) {
        this.frabic = frabic;
    }
    

    public String getFrabic() {
        return frabic;
    }

    
    
    
    
    
    
    
}
