package javaapplication11;
public class ElctronicProduct extends Product {
   private String brand;
   private int warrantyperiod;

public ElctronicProduct(){
    
}

public ElctronicProduct(String name,int productid,float price,String brand,int warrantypeperiod){
 super(productid,name,price);
 this.brand=brand;
 this.warrantyperiod=warrantyperiod;
}

     public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }
    
    public void setWarrantyperiod(int warrantyperiod) {
       if(warrantyperiod>0){ this.warrantyperiod = warrantyperiod;}
       else{this.warrantyperiod =Math.abs(warrantyperiod );}
    }

    public int getWarrantyperiod() {
        return warrantyperiod;
    }

    


   
                    
}
