package javaapplication11;
import java.util.Scanner;
public class JavaApplication11 {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        System.out.println("Welcome to E-Commerec System");
        ElctronicProduct e1=new ElctronicProduct("SmartPhone",1,599.9f,"Samsung",1);
        ClothingProduct c1=new ClothingProduct("T-shirt",2,19.99f,"Medium","Cotton");
        BookProduct b1=new BookProduct("OOP",3,39.99f,"O’Reilly","O’Reilly");
        Customer customer = new Customer();
        System.out.println("Please Enter Your Name: ");
        customer.name=in.nextLine();
        System.out.println("Please Enter Your Id: ");
        customer.customerid=in.nextInt();
        System.out.println("Please Enter Your Address: ");
        customer.address=in.next();
        Cart cart=new Cart();
        cart.setCustomerid(customer.getCustomerid());
        System.out.println("How Many Products You Want To Add in Your Cart? ");
        cart.setnProduct(in.nextInt());
        int addproduct;
        Order o=new Order();
        o.Products=cart.Products;
        o.setCustomerid(customer.customerid);
        o.setorderid(1);
        for(int i=1;i<=cart.getnProduct();i++){
        System.out.println("Which Product you Want to add: "+"\n"+"1- Smart Phone  2- T-shirt  3-OPP"  );
         addproduct=in.nextInt();
         switch(addproduct){
             case 1:
                 cart.addProduct(e1);
               break;
             case 2:
                 cart.addProduct(c1);
              break;
             case 3:
                 cart.addProduct(b1);
              break;
             }
        }
        
        System.out.println("Do you want to Remove any Producd: "+"1-yes "+"2-No ");
        int t=in.nextInt();
        if(t==1){
            System.out.println("What the transiction you want to Remove? ");
            int z=in.nextInt();
            cart.removeProduct(z-1);
        }
        
        
        
        System.out.println("Do you want to place the order: "+"1- yes "+"2-No ");
        int p=in.nextInt();
        cart.placeorder(p);
        if(p==1){
          o.printOrderInfo();
        }
        else{System.out.println("the cart is empty now.\nThank you "+customer.name+" for using our System");}
          
         }
     
  
        
        
        
    
    }
    

